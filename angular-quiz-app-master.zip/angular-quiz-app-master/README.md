# angular-quiz-app — Sample Quiz App
Sample App demonstrating [AngularJS](http://angularjs.org/) concepts & features

##Run server
```bash
node scripts/web-server.js
```

###Navigate to the index page
http://localhost:8000/app/index.html

