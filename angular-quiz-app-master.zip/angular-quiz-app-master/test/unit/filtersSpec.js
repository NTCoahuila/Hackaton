//'use strict';
//
///* jasmine specs for filters go here */
//
//describe('filter', function() {
//
//  beforeEach(module('quiz-app.filters'));
//
//
//  describe('timerDisplay', function() {
//
//    it('Check timer display',
//      inject(function($timerDisplay) {
//        console.log('###### dateFilter = ', $timerDisplay);
//      }));
//  });
//});
