//'use strict';
//
///* jasmine specs for directives go here */
//
//describe('directives', function() {
//  beforeEach(module('quiz-app.directives'));
//
//  var scope, $compile;
//
//  describe('timer', function() {
//
//    it('should display timer', function() {
//      inject(function($compile, $rootScope) {
//        var element = $compile('<h4 class="text-center"></h4>')($rootScope);
//        expect(element.text()).toEqual('TEST_VER');
//      });
//    });
//  });
//});
